import org.jibble.pircbot.*;
import java.util.Timer;

public class MyBot extends PircBot {

    public static final long DURATION = 1 * 30 * 1000;

    private Timer timer = new Timer(true);

    public Boolean delay = false;

    public MyBot() {
        this.setName("SneetosMan");
        
    }
    
    public void onMessage(String channel, String sender,
                       String login, String hostname, String message) {

        if (message.toLowerCase().contains("bit.ly") ){
	sendMessage(channel, "/timeout " + sender + " 600");
	}

        if (delay == false) {
        if ((message.toLowerCase().contains("spring green")  || message.toLowerCase().contains("springgreen")) && delay == false) {

            sendMessage(channel, "/me SPRING GREEN Kreygasm");
            MyBotTimerTask timerTask = new MyBotTimerTask(this, sender, channel);
            timer.schedule(timerTask, DURATION);
	delay = true;

	}

        if (message.contains("TriHard") && delay == false ) {

            sendMessage(channel, "\\TriHard/ HYPE \\TriHard/");
            MyBotTimerTask timerTask = new MyBotTimerTask(this, sender, channel);
            timer.schedule(timerTask, DURATION);
	delay = true;

	}

if ((message.toLowerCase().contains("hax")  || message.toLowerCase().contains("hack")) && delay == false) {

            sendMessage(channel, "Moltob is a HACKERRRRR!!!!");
            MyBotTimerTask timerTask = new MyBotTimerTask(this, sender, channel);
            timer.schedule(timerTask, DURATION);
	delay = true;

	}

	}

    }
}